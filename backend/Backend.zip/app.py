from  flask import Flask, render_template, request, jsonify
from pymongo import MongoClient 
from bson.objectid import ObjectId
from flask_cors import CORS 

app = Flask(__name__)

client = MongoClient('mongodb://localhost:27017')
db=client['devices']
CORS(app)

# Create the 'sensors' and 'gateways' collections
sensors_collection = db['sensors']
gateways_collection = db['gateways']

@app.route('/')
def index():
     return render_template('index.html')

#devices/gateways
@app.route('/gateways' ,methods=['POST','GET'])
def data():
     
     if request.method == 'POST' :
        body= request.json  
        gatewayName = body['gatewayName']
        macAddress = body['macAddress']
        gatewayAddress = body['gatewayAddress']
        cropType = body['cropType']
        farmingType = body['farmingType']
        farmingArea = body['farmingArea']
        climateType = body['climateType']



        db['gateways'].insert_one({
             "gatewayName":gatewayName,
             "macAddress":macAddress,
             "gatewayAddress":gatewayAddress,
             "cropType":cropType,
             "farmingType":farmingType,
             "farmingArea":farmingArea,
             "climateType":climateType

        })

        return jsonify ({
             'status':'Data is posted to MongoDB',
             'gatewayName':gatewayName,
             'macAddress':macAddress,
             'gatewayAddress':gatewayAddress,
             'cropType':cropType,
             'farmingType':farmingType,
             'farmingArea':farmingArea,
             'climateType':climateType
         })
     
     #show all the gateways
     if request.method == 'GET' :
          allData = db['gateways'].find()
          dataJson = []
          for data in allData:
               id=data['_id']
               gatewayName=data['gatewayName']
               macAddress = data['macAddress']
               gatewayAddress = data['gatewayAddress']
               cropType = data['cropType']
               farmingType = data['farmingType']
               farmingArea = data['farmingArea']
               climateType = data['climateType']


               dataDict={
                    "id":str(id),
                    "gatewayName":gatewayName,
                     "macAddress":macAddress,
                     "gatewayAddress":gatewayAddress,
                     "cropType":cropType,
                     "farmingType":farmingType,
                     "farmingArea":farmingArea,
                     "climateType":climateType
               }
               dataJson.append(dataDict)
               print(dataJson)
          return jsonify(dataJson)
     


          #GET a specific data by id

@app.route('/gateways/<string:id>', methods=['GET'])
def get_gateway(id):
               data = db['gateways'].find_one({'_id':ObjectId(id)})
               id = data['_id']
               gatewayName = data['gatewayName']
               macAddress = data['macAddress']
               gatewayAddress = data['gatewayAddress']
               cropType = data['cropType']
               farmingType = data['farmingType']
               farmingArea = data['farmingArea']
               climateType = data['climateType']

               dataDict = {
                    "id":str(id),
                    "gatewayName":gatewayName,
                     "macAddress":macAddress,
                     "gatewayAddress":gatewayAddress,
                     "cropType":cropType,
                     "farmingType":farmingType,
                     "farmingArea":farmingArea,
                     "climateType":climateType
               }
               print (dataDict) 
               return jsonify(dataDict)
          
          #DELETE a data

@app.route('/gateways/<string:id>', methods=['DELETE'])
def delete_gateway(id):
               db['gateways'].delete_many({'_id': ObjectId(id)})
               return jsonify({
                    'status':'Data id:' + id + 'is deleted '
               })
          
 #UPDATE a data 

@app.route('/gateways/<string:id>', methods=['PUT'])
def update_gateway(id):
         
          
     
               body = request.json 
               gatewayName = body['gatewayName']
               macAddress = body['macAddress']
               gatewayAddress = body['gatewayAddress']
               cropType = body['cropType']
               farmingType = body['farmingType']
               farmingArea = body['farmingArea']
               climateType = body['climateType']

               db['gateways'].update_one(
                    {'_id':ObjectId(id)},
                     {
                         "$set":{
                     "gatewayName":gatewayName,
                     "macAddress":macAddress,
                     "gatewayAddress":gatewayAddress,
                     "cropType":cropType,
                     "farmingType":farmingType,
                     "farmingArea":farmingArea,
                     "climateType":climateType
                    }}
               )

#devices/sensors
@app.route('/sensors' , methods=['POST','GET'])
def sensors():
      if request.method == 'POST' :
        body= request.json  
        sensorName = body['sensorName']
        sensorId = body['sensorId']
        temperature = body['temperature']
        humidity = body['humidity']
        soil_moisture = body['soil_moisture']

        sensors_collection.insert_one({
             "sensorName":sensorName,
             "sensorId":sensorId,
             "temperature":temperature,
             "humidity":humidity,
             "soil_moisture":soil_moisture


        })

        return jsonify ({
             'status':'Data is posted to MongoDB',
             'sensorName':sensorName,
             'sensorId':sensorId,    
             'temperature':temperature,
             'humidity':humidity,
             'soil_moisture':soil_moisture
         })
      
       #show all the sensors
      if request.method == 'GET' :
          allData = list(sensors_collection.find())
          dataJson = []
          for data in allData:
               id=data['_id']
               sensorName=data['sensorName']
               sensorId = data['sensorId']
               temperature = data['temperature']
               humidity = data['humidity']
               soil_moisture = data['soil_moisture']
          


               dataDict={
                    "id":str(id),
                    "sensorName":sensorName,
                    "sensorId":sensorId,
                    "temperature":temperature,
                    "humidity":humidity,
                    "soil_moisture":soil_moisture
                   
               }
               dataJson.append(dataDict)
               print(dataJson)
          return jsonify(dataJson)

     
         #GET a specific data by id

@app.route('/sensors/<string:sensor_id>', methods=['GET'])
def get_sensor(sensor_id):
               data = sensors_collection.find_one({'_id':ObjectId(sensor_id)})
               id = data['_id']
               sensorName=data['sensorName']
               sensorId = data['sensorId']
               temperature = data['temperature']
               humidity = data['humidity']
               soil_moisture = data['soil_moisture']

               dataDict = {
                    "id":str(id),
                    "sensorName":sensorName,
                    "sensorId":sensorId,
                    "temperature":temperature,
                    "humidity":humidity,
                    "soil_moisture":soil_moisture
               }
               print (dataDict) 
               return jsonify(dataDict)
 
 #DELETE a data

@app.route('/sensors/<string:sensor_id>', methods=['DELETE'])
def delete_sensor(sensor_id):
               sensors_collection.delete_one({'_id': ObjectId(sensor_id)})==1
               return jsonify({
                    'status':'Data id:' + sensor_id + 'is deleted '
               })
          
#UPDATE a data 

@app.route('/sensors/<string:sensor_id>', methods=['PUT'])
def update_sensor(sensor_id):
         
          
     
               body = request.json 
               sensorName=body['sensorName']
               sensorId = body['sensorId']
               temperature = body['temperature']
               humidity = body['humidity']
               soil_moisture = body['soil_moisture']

               sensors_collection.update_one(
                    {'_id':ObjectId(sensor_id)},
                     {
                         "$set":{
                   "sensorName":sensorName,
                    "sensorId":sensorId,
                    "temperature":temperature,
                    "humidity":humidity,
                    "soil_moisture":soil_moisture
                   
                    }}
               )
               return jsonify({'status': 'Sensor updated successfully'})

     


if __name__=='__main__' :
     app.run(debug=True)